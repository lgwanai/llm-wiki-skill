#!/usr/bin/env python3
"""ocr.py — Image & PDF OCR with pluggable backends.

Backends:
    mineru  (default): MinerU — high-precision parsing, formula→LaTeX, table→HTML, CPU OK.
    paddle:            PaddleOCR — PP-OCRv5, 109 languages, doc unwarping.
    deepseek:          DeepSeek-OCR — grounding + text extraction, local/remote API.

Usage:
    python ocr.py document.pdf                        # Default: MinerU
    python ocr.py document.pdf --backend paddle       # PaddleOCR
    python ocr.py document.pdf --backend deepseek     # DeepSeek-OCR
    python ocr.py document.pdf -o results/            # Output directory
    python ocr.py --batch screenshots/                # Batch process
"""

import argparse
import json
import os
import sys
from pathlib import Path

import yaml

from _deepseek_ocr import DeepSeekOCR
from _mineru_ocr import MinerUOCR
from _paddle_ocr import PaddleOCRWrapper

CONFIG_PATH = Path(__file__).parent.parent / "wiki_config.yaml"


def _get_default_backend() -> str:
    """Read ocr_mode from wiki_config.yaml, default to mineru."""
    if CONFIG_PATH.exists():
        try:
            config = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
            return config.get("ocr_mode", "mineru")
        except Exception:
            pass
    return "mineru"


def main():
    parser = argparse.ArgumentParser(description="Multi-backend OCR — Image & PDF OCR")
    parser.add_argument("file", nargs="?", help="Image or PDF file path")
    parser.add_argument("--backend", choices=["mineru", "paddle", "deepseek"],
                        default=_get_default_backend(),
                        help=f"OCR backend (default: {_get_default_backend()})")
    parser.add_argument("--batch", help="Process all images/PDFs in a directory")
    parser.add_argument("-o", "--output", help="Output directory for PDF results")
    parser.add_argument("-n", "--max-pages", type=int, help="Maximum pages to process")
    args = parser.parse_args()

    if args.backend == "mineru":
        ocr = MinerUOCR.from_config()
    elif args.backend == "paddle":
        ocr = PaddleOCRWrapper.from_config()
    else:
        ocr = DeepSeekOCR.from_config()

    if args.batch:
        if not os.path.isdir(args.batch):
            print(f"Error: not a directory: {args.batch}", file=sys.stderr)
            sys.exit(1)
        supported = {
            ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".tif", ".webp", ".pdf",
        }
        results = []
        for fname in sorted(os.listdir(args.batch)):
            ext = os.path.splitext(fname)[1].lower()
            if ext not in supported:
                continue
            fpath = os.path.join(args.batch, fname)
            if not os.path.isfile(fpath):
                continue
            try:
                if ext == ".pdf":
                    out_dir = Path(args.output or fname.replace(".pdf", "_ocr"))
                    report = ocr.ocr_pdf(fpath, out_dir, max_pages=args.max_pages)
                    results.append({"file": fname, "output": str(report)})
                else:
                    text = ocr.ocr_image(fpath)
                    results.append({"file": fname, "text_length": len(text)})
            except Exception as e:
                print(f"Error processing {fname}: {e}", file=sys.stderr)

        print(json.dumps({"ocr_results": results}, indent=2, ensure_ascii=False))
        return

    if not args.file:
        parser.print_help()
        sys.exit(1)

    ext = os.path.splitext(args.file)[1].lower()
    try:
        if ext == ".pdf":
            out_dir = Path(args.output or Path(args.file).stem + "_ocr")
            report = ocr.ocr_pdf(args.file, out_dir, max_pages=args.max_pages)
            print(f"Output: {report}")
        else:
            text = ocr.ocr_image(args.file)
            print(text)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
